#include <stdio.h>

int main() {
    printf("Hello, C!\n");
    
   int num = 5;
printf("Number: %d\n" , num);

int age;
printf("Enter your age: ");
scanf("%d", &age);
printf("Age: %d\n", age);

    return 0;
} 

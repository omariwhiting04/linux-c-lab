#include <stdio.h>

int main() {
    int a, b;
    printf("Enter first number: "); 
    scanf("%d", &a);
    printf("Enter second number: ");
    scanf("%d", &b);

   int sum = a + b;
   printf("Sum: %d\n", sum);
   
  return 0;

}
